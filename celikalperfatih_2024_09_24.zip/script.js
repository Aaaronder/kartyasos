document.addEventListener("DOMContentLoaded", () => {
    document.getElementById('read').addEventListener("click", () => {
        let backendcurl = "https://retoolapi.dev/PlPhNt/data";
        fetch(backendcurl)
            .then(respsone => respsone.json())
            .then(data => adatokTablazatba(data));
    });
    function adatokTablazatba(adatok) {
        console.log(adatok);
        for (let i = 0; i <adatok.length; i++){
            document.getElementById('id').innerHTML += `<p>
            <div class="card" style="width: 33.3%;">
                <div class="card-body">
                    <div class="idk">
                        <label for="id">Id: </label>
                        <label class="szinek" for="id">${adatok[i].id}</label>
                    </div>
                    <div class="nevek">
                        <label for="nev">Név: </label>
                        <label class="szinek" for="id">${adatok[i].nev}</label>
                    </div>
                    <div class="korok">
                        <label for="age">Kor: </label>
                        <label class="szinek" for="id">${adatok[i].age}</label>
                    </div>
                    <div class="emailcimek">
                        <label for="email">Email cím: </label> <br>
                        <label class="szinek" for="id">${adatok[i].email}</label>
                    </div>
                </div>
            </div>
        </p>`
        }
        //táblázat megjelenítése
        document.getElementById("dolgozok").innerHTML = table;
    }
})